﻿using DAL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DAO
{
    public class EmployeeDAO : EmployeeContext
    {       
        public static void AddEmployee(EMPLOYEE employee)
        {
            try
            {
                db.EMPLOYEEs.InsertOnSubmit(employee);
                db.SubmitChanges();
            }
            catch(Exception x)
            {
                throw x;
            }
        }

        
        public static List<EmployeeDetailDTO> GetEmployees()
        {
            List<EmployeeDetailDTO> emplst = new List<EmployeeDetailDTO>();

            var list = (from e in db.EMPLOYEEs
                        join d in db.DEPARTMENTs
                        on e.DeptID equals d.DepID
                        join p in db.POSITIONs
                        on e.PositionID equals p.ID
                        select new
                        {
                            UserNo = e.UserNo,
                            Name = e.Name,
                            Surname = e.Surname,
                            EmployeeID = e.EmployeeID,
                            Password = e.Password,
                            DepartmentName = d.DepartmentName,
                            DepartmentID = d.DepID,
                            PositionName = p.PositionName,
                            PositionID = p.ID,
                            isAdmin = e.isAdmin,
                            Salary = e.Salary,
                            ImagePath = e.ImagePath,
                            Birthday = e.BirthDay,
                            Address = e.Address
                        }).OrderBy(x => x.UserNo).ToList();

            foreach (var item in list)
            {
                EmployeeDetailDTO dto = new EmployeeDetailDTO();
                dto.UserNo = Convert.ToInt32(item.UserNo);
                dto.Name = item.Name;
                dto.Surname = item.Surname;
                dto.EmployeeID = item.EmployeeID;
                dto.Password = item.Password;
                dto.DepartmentName = item.DepartmentName;
                dto.DepartmentID = item.DepartmentID;
                dto.PositionName = item.PositionName;
                dto.PositionID = item.PositionID;
                dto.isAdmin = Convert.ToBoolean(item.isAdmin);
                dto.Salary = Convert.ToInt32(item.Salary);
                dto.imagePath = item.ImagePath;
                dto.Birthday = Convert.ToDateTime(item.Birthday);
                dto.Address = item.Address;
                emplst.Add(dto);
            }

            return emplst;

        }

        public static void UpdateEmployee(EMPLOYEE employee)
        {
            try
            {
                EMPLOYEE emp = db.EMPLOYEEs.First(x => x.EmployeeID == employee.EmployeeID);
                emp.UserNo = employee.UserNo;
                emp.Name = employee.Name;
                emp.Surname = employee.Surname;
                emp.Password = employee.Password;
                emp.isAdmin = employee.isAdmin;
                emp.BirthDay = employee.BirthDay;
                emp.Address = employee.Address;
                emp.DeptID = employee.DeptID;
                emp.PositionID = employee.PositionID;
                emp.Salary = employee.Salary;
                

                db.SubmitChanges();
            }
            catch (Exception x)
            {
                throw x;
            }
        }

        public static List<EMPLOYEE> GetUsers(int v)
        {
            return db.EMPLOYEEs.Where(x => x.UserNo == v).ToList();
        }
    }
}
