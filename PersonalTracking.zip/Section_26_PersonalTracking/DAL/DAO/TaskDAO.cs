﻿using DAL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DAO
{
    public class TaskDAO : EmployeeContext
    {
        public static List<TASKSTATE> GetTaskState()
        {
            return db.TASKSTATEs.ToList();
        }

        public static void AddTask(TASK task)
        {
            try
            {
                db.TASKs.InsertOnSubmit(task);
                db.SubmitChanges();
            }
            catch (Exception x)
            {

                throw x;
            }
            
        }

        public static List<TaskDetailDTO> GetTask()
        {
            List<TaskDetailDTO> tasklist = new List<TaskDetailDTO>();

            var list = (from t in db.TASKs
                        join s in db.TASKSTATEs on t.TaskState equals s.ID
                        join e in db.EMPLOYEEs on t.EmployeeID equals e.EmployeeID
                        join d in db.DEPARTMENTs on e.DeptID equals d.DepID
                        join p in db.POSITIONs on e.PositionID equals p.ID
                        select new
                        {
                            taskID = t.ID,
                            title = t.TaskTitle,
                            content = t.TaskContent,
                            startdate = t.TaskStartDate,
                            deliverydate = t.TaskDeliveryDate,
                            taskStatename = s.StateName,
                            taskStateID = t.TaskState,
                            UserNo = e.UserNo,
                            EmployeeID = t.EmployeeID,
                            Name = e.Name,
                            Surname = e.Surname,
                            positionName = p.PositionName,
                            departmentName = d.DepartmentName,
                            positionID = e.PositionID,
                            departmentID = e.DeptID
                        }).OrderBy(x => x.startdate).ToList();

            foreach (var item in list)
            {
                TaskDetailDTO dto = new TaskDetailDTO();
                dto.TaskID = item.taskID;
                dto.Title = item.title;
                dto.Content = item.content;
                dto.TaskStartDate = item.startdate;
                dto.TaskDeliveryDate = item.deliverydate;
                dto.TaskStateID = item.taskStateID;
                dto.TaskStateName = item.taskStatename;
                dto.TaskID = item.taskStateID;
                dto.UserNo = (int)item.UserNo;
                dto.EmployeeID = item.EmployeeID;
                dto.Name = item.Name;
                dto.Surname = item.Surname;
                dto.PositionName = item.positionName;
                dto.DepartmentName = item.departmentName;
                dto.PositionID = (int)item.positionID;
                dto.DepartmentID = (int)item.departmentID;
                tasklist.Add(dto);
            }
            return tasklist;
        }
    }
}
