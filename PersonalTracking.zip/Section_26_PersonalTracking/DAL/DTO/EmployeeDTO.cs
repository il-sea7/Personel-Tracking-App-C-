﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.DAO;
using DAL.DTO;

namespace DAL.DTO
{
    public class EmployeeDTO
    {
        public List<DEPARTMENT> Department { get; set; }
        public List<PositionDTO> Position { get; set; }
        public List<EmployeeDetailDTO> Employees { get; set; }

    }
}
