﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;

namespace Section_26_PersonalTracking
{
    public partial class Position : Form
    {
        public Position()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        List<DEPARTMENT> departmentList = new List<DEPARTMENT>();
        private void Position_Load(object sender, EventArgs e)
        {
            departmentList = DepartmentBLL.GetDepartments();
            cbDept.DataSource = departmentList;
            cbDept.DisplayMember = "DepartmentName";
            cbDept.ValueMember = "DepID";
            cbDept.SelectedIndex = -1;
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtPosition.Text.Trim() == "")
            {
                MessageBox.Show("Please fill the Position field");
            }
            else if (cbDept.SelectedIndex == 1)
            {
                MessageBox.Show("Please select the Department field");

            }
            else
            {
                POSITION position = new POSITION();
                position.PositionName = txtPosition.Text;
                position.DeptID = Convert.ToInt32(cbDept.SelectedValue);
               BLL.PositionBLL.AddPosition(position);

                MessageBox.Show("Position was Added");
                txtPosition.Clear();
                cbDept.SelectedIndex = -1;
            }
        }
    }
}
