﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;
using DAL.DTO;
using System.IO;


namespace Section_26_PersonalTracking
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtUserNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }

        private void txtSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }
        EmployeeDTO dto = new EmployeeDTO();
        public EmployeeDetailDTO detail = new EmployeeDetailDTO();
        public bool isUpdate = false;
        string imagepath = "";
        private void Employee_Load(object sender, EventArgs e)
        {
            dto = EmployeeBLL.GetEmployees();
            cbDept.DataSource = dto.Department;
            cbDept.DisplayMember = "DepartmentName";
            cbDept.ValueMember = "DepID";
            cbPosition.DataSource = dto.Position;
            cbPosition.DisplayMember = "PositionName";
            cbPosition.ValueMember = "ID";
            cbDept.SelectedIndex = -1;
            cbPosition.SelectedIndex = -1;
            combofull = true;
            if (isUpdate)
            {
                txtName.Text = detail.Name;
                txtSurame.Text = detail.Surname;
                txtUserNum.Text = detail.UserNo.ToString();
                cbAdmin.Checked = Convert.ToBoolean(detail.isAdmin);
                cbDept.SelectedValue = detail.DepartmentID;
                cbPosition.SelectedValue = detail.PositionID;
                dtpBirthday.Value = Convert.ToDateTime(detail.Birthday);
                txtAddress.Name = detail.Address;
                txtSalary.Text = detail.Salary.ToString();
                imagepath = Application.StartupPath + "\\images\\" + detail.imagePath;
                txtImage.Text = imagepath;
                pictureBox1.ImageLocation = imagepath;
            }
        }
        bool combofull = false;
        private void cbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            //filters positions by selected departments through use of arrow function
            if (combofull)
            {
                int departmentID = Convert.ToInt32(cbDept.SelectedValue);
                cbPosition.DataSource = dto.Position.Where(x => x.DeptID == departmentID).ToList();
            }
           
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Load(openFileDialog1.FileName);
                txtImage.Text = openFileDialog1.FileName;
                string Unique = Guid.NewGuid().ToString();
                filename += Unique + openFileDialog1.SafeFileName;//makes sure each filename is unique
            }
        }
        string filename = "";

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtUserNum.Text.Trim() == "")
            {
                MessageBox.Show("User number is empty");
            }
            else if (!EmployeeBLL.isUnique(Convert.ToInt32(txtUserNum.Text)))
            {
                MessageBox.Show("User number already exists");
            }
            else if (txtPassword.Text.Trim() == "")
            {
                MessageBox.Show("Password is empty");
            }
            else if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("Name is empty");
            }
            else if (txtSurame.Text.Trim() == "")
            {
                MessageBox.Show("Surname is empty");
            }
            else if (txtSalary.Text.Trim() == "")
            {
                MessageBox.Show("Salary is empty");
            }
            else if (cbDept.SelectedIndex == -1)
            {
                MessageBox.Show("Department number is empty");
            }
            else if (cbPosition.SelectedIndex == -1)
            {
                MessageBox.Show("Position is empty");
            }
            else
            {
                if (!isUpdate)
                {
                     if (!EmployeeBLL.isUnique(Convert.ToInt32(txtUserNum.Text)))
                    {
                        MessageBox.Show("User number already exists");
                    }
                    else
                    {
                        //Insert values to employee object
                        EMPLOYEE employee = new EMPLOYEE();
                        employee.UserNo = Convert.ToInt32(txtUserNum.Text);
                        employee.Password = txtPassword.Text;
                        employee.isAdmin = cbAdmin.Checked;
                        employee.Name = txtName.Text;
                        employee.Surname = txtSurame.Text;
                        employee.Salary = Convert.ToInt32(txtSalary.Text);
                        employee.DeptID = Convert.ToInt32(cbDept.SelectedValue);
                        employee.PositionID = Convert.ToInt32(cbPosition.SelectedValue);
                        employee.Address = txtAddress.Text;
                        employee.BirthDay = Convert.ToDateTime(dtpBirthday.Value);
                        employee.ImagePath = filename;
                        EmployeeBLL.AddEmployee(employee);


                        //Copies the path of the images
                        File.Copy(txtImage.Text, @"images\\" + filename);
                        MessageBox.Show("Employee was added");

                        txtUserNum.Clear();
                        txtPassword.Clear();
                        cbAdmin.Checked = false;
                        txtSurame.Clear();
                        txtName.Clear();
                        txtSalary.Clear();
                        cbDept.SelectedIndex = -1;
                        cbPosition.SelectedIndex = -1;
                        txtAddress.Clear();
                        dtpBirthday.Value = DateTime.Today;
                        txtImage.Clear();
                        combofull = true;
                    }
                    
                }
                else
                {
                    DialogResult result = MessageBox.Show("are you sure?,", "Warning", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EMPLOYEE employee = new EMPLOYEE();
                        if(txtImage.Text!= imagepath)
                        {
                            if (File.Exists(@"images\\" + detail.imagePath))
                            {
                                File.Delete(@"images\\" + detail.imagePath);
                                File.Copy(txtImage.Text, @"images\\" + filename);
                                employee.ImagePath = filename;
                            }
                            else
                            {
                                employee.UserNo = Convert.ToInt32(txtUserNum.Text);
                                employee.Password = txtPassword.Text;
                                employee.isAdmin = cbAdmin.Checked;
                                employee.Name = txtName.Text;
                                employee.Surname = txtSurame.Text;
                                employee.Salary = Convert.ToInt32(txtSalary.Text);
                                employee.DeptID = Convert.ToInt32(cbDept.SelectedValue);
                                employee.PositionID = Convert.ToInt32(cbPosition.SelectedValue);
                                employee.Address = txtAddress.Text;
                                employee.BirthDay = dtpBirthday.Value;
                                employee.ImagePath = filename;
                                EmployeeBLL.UpdateEmployee(employee);
                                MessageBox.Show("Employee was updated");
                                this.Close();
                            }

                        }
                    }
                }

            }


        }

        bool isUnique = false;
        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (txtUserNum.Text.Trim() == "")
            {
                MessageBox.Show("User number is empty");
            }
            else
            {
                isUnique = EmployeeBLL.isUnique(Convert.ToInt32(txtUserNum.Text));
                if (!isUnique)
                {
                    MessageBox.Show("User number already exists");
                }
                else
                {
                    MessageBox.Show("This user number is usable");

                }
            }
        }
    }
}
