﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL.DTO;
using DAL;


namespace Section_26_PersonalTracking
{
    public partial class Task : Form
    {
        public Task()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        TaskDTO dto = new TaskDTO();
        private bool combofull;

        private void Task_Load(object sender, EventArgs e)
        {
            lblTask.Visible = false;
            cbTaskState.Visible = false;
            dto = TaskBLL.GetAll();
            dgvEmployees.DataSource = dto.Employees;
            dgvEmployees.Columns[0].Visible = false;
            dgvEmployees.Columns[1].HeaderText = "User No";
            dgvEmployees.Columns[2].HeaderText = "Name";
            dgvEmployees.Columns[3].HeaderText = "Surname";
            dgvEmployees.Columns[4].Visible = false;
            dgvEmployees.Columns[5].Visible = false;
            dgvEmployees.Columns[6].Visible = false;
            dgvEmployees.Columns[7].Visible = false;
            dgvEmployees.Columns[8].Visible = false;
            dgvEmployees.Columns[9].Visible = false;
            dgvEmployees.Columns[10].Visible = false;
            dgvEmployees.Columns[11].Visible = false;
            dgvEmployees.Columns[12].Visible = false;

            combofull = false;

            cbDept.DataSource = dto.Department;
            cbDept.DisplayMember = "DepartmentName";
            cbDept.ValueMember = "DepID";
            cbPosition.DataSource = dto.Positions;
            cbPosition.DisplayMember = "PositionName";
            cbPosition.ValueMember = "ID";
            cbDept.SelectedIndex = -1;
            cbPosition.SelectedIndex = -1;

            combofull = true;

            cbTaskState.DataSource = dto.TaskState;
            cbTaskState.DisplayMember = "StateName";
            cbTaskState.ValueMember = "ID";
            cbTaskState.SelectedIndex = -1;


        }

        private void cbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combofull)
            {
                cbPosition.DataSource = dto.Positions.Where(x => x.DeptID ==
                Convert.ToInt32(cbDept.SelectedValue)).ToList();

                List<EmployeeDetailDTO> lst = dto.Employees;
                dgvEmployees.DataSource = lst.Where(x => x.DepartmentID ==
                Convert.ToInt32(cbDept.SelectedValue)).ToList();
            }
            
        }

        private void dgvEmployees_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtUserNum.Text = dgvEmployees.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtName.Text = dgvEmployees.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtSurame.Text = dgvEmployees.Rows[e.RowIndex].Cells[3].Value.ToString();
            task.EmployeeID = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[0].Value);
        }

        private void cbPosition_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combofull)
            {              
                List<EmployeeDetailDTO> lst = dto.Employees;
                dgvEmployees.DataSource = lst.Where(x => x.PositionID ==
                Convert.ToInt32(cbPosition.SelectedValue)).ToList();
            }
           
        }
        TASK task = new TASK();
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (task.EmployeeID == 0)
            {
                MessageBox.Show("Please select an employee on table");
            }
            else if (txtTitle.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in a task title");
            }
            else if (txtContent.Text.Trim() == "")
            {
                MessageBox.Show("Please fill in a task content");
            }           
            else
            {
                task.TaskTitle = txtTitle.Text;
                task.TaskContent = txtContent.Text;
                task.TaskStartDate = DateTime.Today;
                task.TaskState = 1;
                TaskBLL.AddTask(task);
                MessageBox.Show("Task has been added");

                txtTitle.Clear();
                txtContent.Clear();
                task = new TASK();
            }

        }
    }
}
