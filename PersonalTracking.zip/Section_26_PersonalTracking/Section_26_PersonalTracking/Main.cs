﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Section_26_PersonalTracking
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void ibtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ibtnEmployee_Click(object sender, EventArgs e)
        {
            EmployeeList frm = new EmployeeList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;    //show this form when we close emploeelist
        }

        private void ibtnTasks_Click(object sender, EventArgs e)
        {
            TaskList frm = new TaskList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void ibtnSalary_Click(object sender, EventArgs e)
        {
            SalaryList frm = new SalaryList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void ibtnPermission_Click(object sender, EventArgs e)
        {
            PermissionList frm = new PermissionList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void ibtnDepartment_Click(object sender, EventArgs e)
        {
            DepartmentList frm = new DepartmentList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void ibtnPosition_Click(object sender, EventArgs e)
        {
            PositionList frm = new PositionList();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void ibtnLogout_Click(object sender, EventArgs e)
        {
            Login frm = new Login();
            this.Hide();
            frm.ShowDialog();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }    
}
