﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;

namespace Section_26_PersonalTracking
{
    public partial class DepartmentList : Form
    {
        public DepartmentList()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Department frm = new Department();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;

            list = DepartmentBLL.GetDepartments();
            dgvDept.DataSource = list;         
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Department frm = new Department();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }
        List<DEPARTMENT> list = new List<DEPARTMENT>();
        private void DepartmentList_Load(object sender, EventArgs e)
        {
            
            list = DepartmentBLL.GetDepartments();
            dgvDept.DataSource = list;
            dgvDept.Columns[0].Visible = false;
            dgvDept.Columns[1].HeaderText = "Department Name";

        }
    }
}
