﻿
namespace Section_26_PersonalTracking
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FontAwesome.Sharp.IconButton ibtnExit;
            this.ibtnEmployee = new FontAwesome.Sharp.IconButton();
            this.ibtnTasks = new FontAwesome.Sharp.IconButton();
            this.ibtnSalary = new FontAwesome.Sharp.IconButton();
            this.ibtnPermission = new FontAwesome.Sharp.IconButton();
            this.ibtnDepartment = new FontAwesome.Sharp.IconButton();
            this.ibtnPosition = new FontAwesome.Sharp.IconButton();
            this.ibtnLogout = new FontAwesome.Sharp.IconButton();
            ibtnExit = new FontAwesome.Sharp.IconButton();
            this.SuspendLayout();
            // 
            // ibtnExit
            // 
            ibtnExit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            ibtnExit.IconChar = FontAwesome.Sharp.IconChar.ExternalLinkAlt;
            ibtnExit.IconColor = System.Drawing.Color.Black;
            ibtnExit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            ibtnExit.IconSize = 100;
            ibtnExit.Location = new System.Drawing.Point(570, 209);
            ibtnExit.Name = "ibtnExit";
            ibtnExit.Size = new System.Drawing.Size(150, 154);
            ibtnExit.TabIndex = 7;
            ibtnExit.Text = "Exit";
            ibtnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            ibtnExit.UseVisualStyleBackColor = true;
            ibtnExit.Click += new System.EventHandler(this.ibtnExit_Click);
            // 
            // ibtnEmployee
            // 
            this.ibtnEmployee.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnEmployee.IconChar = FontAwesome.Sharp.IconChar.UsersCog;
            this.ibtnEmployee.IconColor = System.Drawing.Color.Black;
            this.ibtnEmployee.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnEmployee.IconSize = 100;
            this.ibtnEmployee.Location = new System.Drawing.Point(13, 13);
            this.ibtnEmployee.Name = "ibtnEmployee";
            this.ibtnEmployee.Size = new System.Drawing.Size(150, 154);
            this.ibtnEmployee.TabIndex = 0;
            this.ibtnEmployee.Text = "Employees";
            this.ibtnEmployee.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnEmployee.UseVisualStyleBackColor = true;
            this.ibtnEmployee.Click += new System.EventHandler(this.ibtnEmployee_Click);
            // 
            // ibtnTasks
            // 
            this.ibtnTasks.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnTasks.IconChar = FontAwesome.Sharp.IconChar.ClipboardList;
            this.ibtnTasks.IconColor = System.Drawing.Color.Black;
            this.ibtnTasks.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnTasks.IconSize = 100;
            this.ibtnTasks.Location = new System.Drawing.Point(195, 13);
            this.ibtnTasks.Name = "ibtnTasks";
            this.ibtnTasks.Size = new System.Drawing.Size(150, 154);
            this.ibtnTasks.TabIndex = 1;
            this.ibtnTasks.Text = "Tasks";
            this.ibtnTasks.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnTasks.UseVisualStyleBackColor = true;
            this.ibtnTasks.Click += new System.EventHandler(this.ibtnTasks_Click);
            // 
            // ibtnSalary
            // 
            this.ibtnSalary.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnSalary.IconChar = FontAwesome.Sharp.IconChar.Donate;
            this.ibtnSalary.IconColor = System.Drawing.Color.Black;
            this.ibtnSalary.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnSalary.IconSize = 100;
            this.ibtnSalary.Location = new System.Drawing.Point(377, 12);
            this.ibtnSalary.Name = "ibtnSalary";
            this.ibtnSalary.Size = new System.Drawing.Size(150, 154);
            this.ibtnSalary.TabIndex = 2;
            this.ibtnSalary.Text = "Salary";
            this.ibtnSalary.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnSalary.UseVisualStyleBackColor = true;
            this.ibtnSalary.Click += new System.EventHandler(this.ibtnSalary_Click);
            // 
            // ibtnPermission
            // 
            this.ibtnPermission.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnPermission.IconChar = FontAwesome.Sharp.IconChar.Cogs;
            this.ibtnPermission.IconColor = System.Drawing.Color.Black;
            this.ibtnPermission.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnPermission.IconSize = 100;
            this.ibtnPermission.Location = new System.Drawing.Point(570, 12);
            this.ibtnPermission.Name = "ibtnPermission";
            this.ibtnPermission.Size = new System.Drawing.Size(150, 154);
            this.ibtnPermission.TabIndex = 3;
            this.ibtnPermission.Text = "Permission";
            this.ibtnPermission.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnPermission.UseVisualStyleBackColor = true;
            this.ibtnPermission.Click += new System.EventHandler(this.ibtnPermission_Click);
            // 
            // ibtnDepartment
            // 
            this.ibtnDepartment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnDepartment.IconChar = FontAwesome.Sharp.IconChar.Empire;
            this.ibtnDepartment.IconColor = System.Drawing.Color.Black;
            this.ibtnDepartment.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnDepartment.IconSize = 100;
            this.ibtnDepartment.Location = new System.Drawing.Point(13, 209);
            this.ibtnDepartment.Name = "ibtnDepartment";
            this.ibtnDepartment.Size = new System.Drawing.Size(150, 154);
            this.ibtnDepartment.TabIndex = 4;
            this.ibtnDepartment.Text = "Department";
            this.ibtnDepartment.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnDepartment.UseVisualStyleBackColor = true;
            this.ibtnDepartment.Click += new System.EventHandler(this.ibtnDepartment_Click);
            // 
            // ibtnPosition
            // 
            this.ibtnPosition.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnPosition.IconChar = FontAwesome.Sharp.IconChar.Dharmachakra;
            this.ibtnPosition.IconColor = System.Drawing.Color.Black;
            this.ibtnPosition.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnPosition.IconSize = 100;
            this.ibtnPosition.Location = new System.Drawing.Point(185, 209);
            this.ibtnPosition.Name = "ibtnPosition";
            this.ibtnPosition.Size = new System.Drawing.Size(150, 154);
            this.ibtnPosition.TabIndex = 5;
            this.ibtnPosition.Text = "Position";
            this.ibtnPosition.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnPosition.UseVisualStyleBackColor = true;
            this.ibtnPosition.Click += new System.EventHandler(this.ibtnPosition_Click);
            // 
            // ibtnLogout
            // 
            this.ibtnLogout.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibtnLogout.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.ibtnLogout.IconColor = System.Drawing.Color.Black;
            this.ibtnLogout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ibtnLogout.IconSize = 100;
            this.ibtnLogout.Location = new System.Drawing.Point(377, 209);
            this.ibtnLogout.Name = "ibtnLogout";
            this.ibtnLogout.Size = new System.Drawing.Size(150, 154);
            this.ibtnLogout.TabIndex = 6;
            this.ibtnLogout.Text = "Logout";
            this.ibtnLogout.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ibtnLogout.UseVisualStyleBackColor = true;
            this.ibtnLogout.Click += new System.EventHandler(this.ibtnLogout_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(ibtnExit);
            this.Controls.Add(this.ibtnLogout);
            this.Controls.Add(this.ibtnPosition);
            this.Controls.Add(this.ibtnDepartment);
            this.Controls.Add(this.ibtnPermission);
            this.Controls.Add(this.ibtnSalary);
            this.Controls.Add(this.ibtnTasks);
            this.Controls.Add(this.ibtnEmployee);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Tracking";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private FontAwesome.Sharp.IconButton ibtnEmployee;
        private FontAwesome.Sharp.IconButton ibtnTasks;
        private FontAwesome.Sharp.IconButton ibtnSalary;
        private FontAwesome.Sharp.IconButton ibtnPermission;
        private FontAwesome.Sharp.IconButton ibtnDepartment;
        private FontAwesome.Sharp.IconButton ibtnPosition;
        private FontAwesome.Sharp.IconButton ibtnLogout;
    }
}