﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;
using DAL.DTO;
using System.IO;
using DAL.DAO;

namespace Section_26_PersonalTracking
{
    public partial class EmployeeList : Form
    {
        public EmployeeList()
        {
            InitializeComponent();
        }

        private void txtUserNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Employee frm = new Employee();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
            FillData();
            ClearData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (detail.EmployeeID == 0)
            {
                MessageBox.Show("Please select employee");
            }
            else
            {
                Employee frm = new Employee();
                this.Hide();
                frm.isUpdate = true;
                frm.ShowDialog();
                this.Visible = true;
                FillData();
                ClearData();
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
           
        }
        EmployeeDTO dto = new EmployeeDTO();

        private bool combofull = false;
        EmployeeDetailDTO detail = new EmployeeDetailDTO();
        void FillData()
        {
            dto = EmployeeBLL.GetEmployees();
            dgvEmployees.DataSource = dto.Employees;
            dgvEmployees.Columns[0].Visible = false;
            dgvEmployees.Columns[1].HeaderText = "User No";
            dgvEmployees.Columns[2].Visible = false;
            dgvEmployees.Columns[3].HeaderText = "Name";
            dgvEmployees.Columns[4].HeaderText = "Surname";
            dgvEmployees.Columns[5].HeaderText = "Department";
            dgvEmployees.Columns[6].HeaderText = "Position";
            dgvEmployees.Columns[7].Visible = false;
            dgvEmployees.Columns[8].Visible = false;
            dgvEmployees.Columns[9].HeaderText = "Salary";
            dgvEmployees.Columns[10].Visible = false;
            dgvEmployees.Columns[11].Visible = false;
            dgvEmployees.Columns[12].Visible = false;
            dgvEmployees.Columns[13].Visible = false;

            combofull = false;

            cmbDept.DataSource = dto.Department;
            cmbDept.DisplayMember = "DepartmentName";
            cmbDept.ValueMember = "DepID";
            cbPosition.DataSource = dto.Position;
            cbPosition.DisplayMember = "PositionName";
            cbPosition.ValueMember = "ID";
            cmbDept.SelectedIndex = -1;
            cbPosition.SelectedIndex = -1;

            combofull = true;
        }
        private void EmployeeList_Load(object sender, EventArgs e)
        {

            FillData();
        }

        private void cmbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combofull)
            {
                cbPosition.DataSource = dto.Position.Where(x => x.DeptID ==
                Convert.ToInt32(cmbDept.SelectedValue)).ToList();
            }
            //if (combofull)
            //{
            //    int departmentID = Convert.ToInt32(cmbDept.SelectedValue);
            //    cbPosition.DataSource = dto.Position.Where(x => x.DeptID == departmentID).ToList();
            //}
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<EmployeeDetailDTO> lst = dto.Employees;
            if (txtUserNum.Text.Trim() != "")
            {
                lst = lst.Where(x => x.UserNo == Convert.ToInt32(txtUserNum.Text)).ToList();
            }
            if (txtName.Text.Trim() != "")
            {
                lst = lst.Where(x => x.Name.Contains(txtName.Text)).ToList();
            }
            if (txtSurame.Text.Trim() != "")
            {
                lst = lst.Where(x => x.Surname.Contains(txtSurame.Text)).ToList();
            }
            if (cmbDept.SelectedIndex != -1)
            {
                lst = lst.Where(x => x.DepartmentID == Convert.ToInt32(cmbDept.SelectedValue)).ToList();
            }
            if (cbPosition.SelectedIndex != -1)
            {
                lst = lst.Where(x => x.PositionID == Convert.ToInt32(cbPosition.SelectedValue)).ToList();
            }
            dgvEmployees.DataSource = lst;
        }
        void ClearData()
        {
            txtUserNum.Clear();
            txtName.Clear();
            txtSurame.Clear();
            combofull = false;
            cmbDept.SelectedIndex = -1;
            cbPosition.DataSource = dto.Position;
            cbPosition.SelectedIndex = -1;
            combofull = false;

            dgvEmployees.DataSource = dto.Employees;
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void dgvEmployees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvEmployees_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            detail.EmployeeID = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[0].Value);
            detail.UserNo = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[1].Value);
            detail.Password = dgvEmployees.Rows[e.RowIndex].Cells[2].Value.ToString();
            detail.Name = dgvEmployees.Rows[e.RowIndex].Cells[3].Value.ToString();
            detail.Surname = dgvEmployees.Rows[e.RowIndex].Cells[4].Value.ToString();
            detail.DepartmentID = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[7].Value);
            detail.PositionID = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[8].Value);
            detail.Salary = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells[9].Value);
            detail.isAdmin = Convert.ToBoolean(dgvEmployees.Rows[e.RowIndex].Cells[10].Value);
            detail.imagePath = dgvEmployees.Rows[e.RowIndex].Cells[11].Value.ToString();
            detail.Address = dgvEmployees.Rows[e.RowIndex].Cells[12].Value.ToString();
            detail.Birthday = Convert.ToDateTime(dgvEmployees.Rows[e.RowIndex].Cells[13].Value);
        }
    }
}
