﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using DAL.DTO;
using BLL;

namespace Section_26_PersonalTracking
{
    public partial class TaskList : Form
    {
        public TaskList()
        {
            InitializeComponent();
        }

        private void txtUserNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFilters();
        }

        private void ClearFilters()
        {
            txtUserNum.Clear();
            txtName.Clear();
            txtSurame.Clear();
            combofull = false;
            cbDept.SelectedIndex = -1;
            cbPosition.DataSource = dto.Positions;
            cbPosition.SelectedIndex = -1;
            combofull = false;
            rbtnDelivery.Checked = false;
            rbtnStart.Checked = false;
            cbTaskState.SelectedIndex = -1;

            dgvEmployees.DataSource = dto.Tasks;
        }

        TaskDTO dto = new TaskDTO();
        private bool combofull;
        void FillAllData()
        {
            dto = TaskBLL.GetAll();
            dgvEmployees.DataSource = dto.Tasks;

            combofull = false;

            cbDept.DataSource = dto.Department;
            cbDept.DisplayMember = "DepartmentName";
            cbDept.ValueMember = "DepID";
            cbPosition.DataSource = dto.Positions;
            cbPosition.DisplayMember = "PositionName";
            cbPosition.ValueMember = "ID";
            cbDept.SelectedIndex = -1;
            cbPosition.SelectedIndex = -1;

            combofull = true;

            cbTaskState.DataSource = dto.TaskState;
            cbTaskState.DisplayMember = "StateName";
            cbTaskState.ValueMember = "ID";
            cbTaskState.SelectedIndex = -1;
        }

        private void TaskList_Load(object sender, EventArgs e)
        {
            FillAllData();
            
            dgvEmployees.Columns[11].HeaderText = "Task Title";
            dgvEmployees.Columns[1].HeaderText = "User No";
            dgvEmployees.Columns[2].HeaderText = "Name";
            dgvEmployees.Columns[3].HeaderText = "Surname";
            dgvEmployees.Columns[14].HeaderText = "Start Date";
            dgvEmployees.Columns[15].HeaderText = "Delivery Date";
            dgvEmployees.Columns[13].HeaderText = "Task State";
            dgvEmployees.Columns[7].Visible = false;
            dgvEmployees.Columns[8].Visible = false;
            dgvEmployees.Columns[9].Visible = false;
            dgvEmployees.Columns[10].Visible = false;
            dgvEmployees.Columns[0].Visible = false;
            dgvEmployees.Columns[12].Visible = false;
            dgvEmployees.Columns[6].Visible = false;
            dgvEmployees.Columns[4].Visible = false;
            dgvEmployees.Columns[5].Visible = false;        
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
            FillAllData();
            ClearFilters();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combofull)
            {
                cbPosition.DataSource = dto.Positions.Where(x => x.DeptID ==
                Convert.ToInt32(cbDept.SelectedValue)).ToList();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<TaskDetailDTO> lst = dto.Tasks;
            
            if (txtUserNum.Text.Trim() != "")
            {
                
                lst = lst.Where(x => x.UserNo == Convert.ToInt32(txtUserNum.Text)).ToList();
            }
            if (txtName.Text.Trim() != "")
            {
                lst = lst.Where(x => x.Name.Contains(txtName.Text)).ToList();
            }
            if (txtSurame.Text.Trim() != "")
            {
                lst = lst.Where(x => x.Surname.Contains(txtSurame.Text)).ToList();
            }
            if (cbDept.SelectedIndex != -1)
            {
                lst = lst.Where(x => x.DepartmentID == Convert.ToInt32(cbDept.SelectedValue)).ToList();
            }
            if (cbPosition.SelectedIndex != -1)
            {
                lst = lst.Where(x => x.PositionID == Convert.ToInt32(cbPosition.SelectedValue)).ToList();
            }
            if (rbtnStart.Checked)
            {
                lst = lst.Where(x => x.TaskStartDate > Convert.ToDateTime(dtpStart.Value) && x.TaskStartDate < Convert.ToDateTime(dtpFinish.Value)).ToList(); ;
            }
            if (rbtnDelivery.Checked)
            {
                lst = lst.Where(x => x.TaskDeliveryDate > Convert.ToDateTime(dtpStart.Value) && x.TaskDeliveryDate < Convert.ToDateTime(dtpFinish.Value)).ToList(); ;
            }
            if(cbTaskState.SelectedIndex != -1)
            {
                lst = lst.Where(x => x.TaskStateID == Convert.ToInt32(cbTaskState.SelectedValue)).ToList();
                dgvEmployees.DataSource = lst;
            }
            dgvEmployees.DataSource = lst;
        }
    }
}
