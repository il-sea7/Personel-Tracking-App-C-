﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Section_26_PersonalTracking
{
    public partial class PermissionList : Form
    {
        public PermissionList()
        {
            InitializeComponent();
        }

        private void txtUserNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }

        private void txtDayAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = General.isNumber(e);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PermissionList_Load(object sender, EventArgs e)
        {
            pnlAdmin.Hide();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Permission frm = new Permission();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Permission frm = new Permission();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }
    }
}
