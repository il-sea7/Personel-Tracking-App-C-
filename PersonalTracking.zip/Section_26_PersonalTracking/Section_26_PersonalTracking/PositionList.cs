﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL.DTO;

namespace Section_26_PersonalTracking
{
    public partial class PositionList : Form
    {
        public PositionList()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Position frm = new Position();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Position frm = new Position();
            this.Hide();
            frm.ShowDialog();
            this.Visible = true;
        }
        List<PositionDTO> positionsList = new List<PositionDTO>();

        void FillGrid()
        {
            positionsList = PositionBLL.GetPositions();
            dgvPosition.DataSource = positionsList;
        }
        private void PositionList_Load(object sender, EventArgs e)
        {
            FillGrid();
            positionsList = PositionBLL.GetPositions();
            dgvPosition.DataSource = positionsList;

            dgvPosition.Columns[0].HeaderText = "Department Name";
            dgvPosition.Columns[1].Visible = false;
            dgvPosition.Columns[2].Visible = false;
            dgvPosition.Columns[3].HeaderText = "Position Name";
        }
    }
}
