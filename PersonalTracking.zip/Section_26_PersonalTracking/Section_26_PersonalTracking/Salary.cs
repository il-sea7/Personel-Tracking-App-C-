﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;
using DAL.DTO;

namespace Section_26_PersonalTracking
{
    public partial class Salary : Form
    {
        public Salary()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        SalaryDTO dto = new SalaryDTO();
        private void Salary_Load(object sender, EventArgs e)
        {
            //dto = SalaryBLL.GetAll();
        }


    }
}
