﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.DAO;
using DAL.DTO;

namespace BLL
{
    public class EmployeeBLL
    {
        public static EmployeeDTO GetEmployees()
        {
            EmployeeDTO dto = new EmployeeDTO();
            dto.Department = DepartmentDAO.GetDepartments();
            dto.Position = PositionDAO.GetPositions();
            dto.Employees = EmployeeDAO.GetEmployees();
            return dto;
        }

        public static void AddEmployee(EMPLOYEE employee)
        {
            EmployeeDAO.AddEmployee(employee);
        }

        public static bool isUnique(int v)
        {
            List<EMPLOYEE> lst = EmployeeDAO.GetUsers(v);
            if (lst.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static void UpdateEmployee(EMPLOYEE employee)
        {
            EmployeeDAO.UpdateEmployee(employee);
        }
    }
}
